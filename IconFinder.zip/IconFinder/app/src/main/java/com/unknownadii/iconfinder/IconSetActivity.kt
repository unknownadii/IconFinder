package com.unknownadii.iconfinder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.unknownadii.iconfinder.Models.RvIconSetData
import com.unknownadii.iconfinder.api.IconApi
import com.unknownadii.iconfinder.databinding.ActivityIconSetBinding
import com.unknownadii.iconfinder.main.MainRepository
import com.unknownadii.iconfinder.main.MainViewModel
import com.unknownadii.iconfinder.main.MainViewModelFactory
import com.unknownadii.iconfinder.recyclerview.IconSetAdapter
import java.util.*

class IconSetActivity : AppCompatActivity(), IconSetAdapter.moveToIcon {
    lateinit var binding: ActivityIconSetBinding
    lateinit var mainViewModel: MainViewModel
    private val retrofitService = IconApi.getInstance()
    lateinit var dataIconSet: ArrayList<RvIconSetData>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIconSetBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val intent = intent
        val str = intent.getStringExtra("categoryName")
        //binding.tv.text = str

        setSupportActionBar(binding.topAppBarIconSet)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.topAppBarIconSet.setNavigationOnClickListener {
            onBackPressed()
        }

        dataIconSet = ArrayList()
        binding.progressBarIconSet.isVisible = true
        mainViewModel =
            ViewModelProvider(this, MainViewModelFactory(MainRepository(retrofitService))).get(
                MainViewModel::class.java
            )

        if (str != null) {
            getIconSetItem(str, 50)
        }
        binding.rvIconSet.layoutManager = LinearLayoutManager(this);
        val adapter = IconSetAdapter(dataIconSet, this)
        binding.rvIconSet.adapter = adapter
    }

    private fun getIconSetItem(categoryName: String, count: Int) {
        mainViewModel.getIconSet(categoryName, count)
        mainViewModel.iconSetLiveData.observe(this) {
            val length = it.iconsets.size
            for (i in 1 until length) {
                val nameValue = it.iconsets[i].name
                val idValue = it.iconsets[i].iconset_id
                dataIconSet.add(
                    RvIconSetData(
                        "Name:- ",
                        nameValue,
                        "IconSet Id:- ",
                        idValue.toString(),
                        R.drawable.ic_baseline_arrow_forward_24
                    )
                )
            }
            binding.progressBarIconSet.isVisible = false
        }
    }

    override fun redirectToIcon(id: String) {
        val intent = Intent(this@IconSetActivity, IconActivity::class.java)
        intent.putExtra("id", id)
        startActivity(intent)
    }

}