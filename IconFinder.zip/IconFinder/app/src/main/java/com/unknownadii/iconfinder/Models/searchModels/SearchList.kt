package com.unknownadii.iconfinder.Models.searchModels

data class SearchList(
    val icons: List<Icon>,
    val total_count: Int
)