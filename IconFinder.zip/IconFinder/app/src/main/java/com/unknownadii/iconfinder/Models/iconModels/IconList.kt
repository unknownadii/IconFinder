package com.unknownadii.iconfinder.Models.iconModels

data class IconList(
    val icons: List<Icon>,
    val total_count: Int
)