package com.unknownadii.iconfinder.Models.searchModels

data class Icon(
    val icon_id: Int,
    val is_icon_glyph: Boolean,
    val is_premium: Boolean,
    val published_at: String,
    val raster_sizes: List<RasterSize>,
    val tags: List<String>,
    val type: String,
)