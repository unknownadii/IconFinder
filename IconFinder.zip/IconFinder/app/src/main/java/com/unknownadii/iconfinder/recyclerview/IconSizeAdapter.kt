package com.unknownadii.iconfinder.recyclerview

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.toDrawable
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.unknownadii.iconfinder.Models.RvCategoryData
import com.unknownadii.iconfinder.Models.RvIconData
import com.unknownadii.iconfinder.Models.RvIconSizeData
import com.unknownadii.iconfinder.R

class IconSizeAdapter(private val mList: List<RvIconSizeData>) :
    RecyclerView.Adapter<IconSizeAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.rv_icon_size, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val iconSizeViewModel = mList[position]
        if (position % 5 == 0) {
            holder.llName.setBackgroundResource(R.color.light_pink)
            holder.llName2.setBackgroundResource(R.color.light_pink)
            holder.llName3.setBackgroundResource(R.color.light_pink)
        } else if (position % 2 == 0) {
            holder.llName.setBackgroundResource(R.color.light_blue)
            holder.llName2.setBackgroundResource(R.color.light_blue)
            holder.llName3.setBackgroundResource(R.color.light_blue)
        } else if (position % 2 != 0) {
            holder.llName.setBackgroundResource(R.color.light_green)
            holder.llName2.setBackgroundResource(R.color.light_green)
            holder.llName3.setBackgroundResource(R.color.light_green)
        }
        val icon = iconSizeViewModel.icon
        val imgDownload = iconSizeViewModel.download
        Glide.with(holder.icon.context)
            .load(icon)
            .into(holder.icon)
        Glide.with(holder.download.context)
            .load(imgDownload)
            .into(holder.download)

        holder.name.text = iconSizeViewModel.size
        holder.nameValue.text = iconSizeViewModel.sizeValue

        holder.idName.text = iconSizeViewModel.iconId
        holder.idNameValue.text = iconSizeViewModel.iconIdValue.toString()

        holder.download.setOnClickListener {
            // move.redirectToIconSize()
        }

    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val icon: ImageView = itemView.findViewById(R.id.iconIconSize)
        val download: ImageView = itemView.findViewById(R.id.iconDownloadIconSize)
        val llName: LinearLayout = itemView.findViewById(R.id.llRvIconSize)
        val llName2: LinearLayout = itemView.findViewById(R.id.llRvIconSize2)
        val llName3: LinearLayout = itemView.findViewById(R.id.llRvIcon2IconSize)
        val name: TextView = itemView.findViewById(R.id.tvIconName)
        val nameValue: TextView = itemView.findViewById(R.id.tvIconNameValue)
        val idName: TextView = itemView.findViewById(R.id.tvRealIconSizeName)
        val idNameValue: TextView = itemView.findViewById(R.id.tvRealIconSizeNameValue)
    }

}