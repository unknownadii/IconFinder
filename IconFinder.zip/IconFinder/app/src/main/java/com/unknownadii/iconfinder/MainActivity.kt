package com.unknownadii.iconfinder


import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.View
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.unknownadii.iconfinder.Models.RvCategoryData
import com.unknownadii.iconfinder.Models.RvSearchData
import com.unknownadii.iconfinder.api.IconApi
import com.unknownadii.iconfinder.databinding.ActivityMainBinding
import com.unknownadii.iconfinder.main.MainRepository
import com.unknownadii.iconfinder.main.MainViewModel
import com.unknownadii.iconfinder.main.MainViewModelFactory
import com.unknownadii.iconfinder.recyclerview.CategoryAdapter
import com.unknownadii.iconfinder.recyclerview.SearchAdapter
import java.net.InetAddress
import java.net.UnknownHostException


class MainActivity : AppCompatActivity(), CategoryAdapter.moveToIconSet {

    private lateinit var binding: ActivityMainBinding
    lateinit var mainViewModel: MainViewModel
    private val retrofitService = IconApi.getInstance()
    lateinit var searchAdapter: SearchAdapter
    lateinit var rvSearch: RecyclerView
    lateinit var dataCategory: ArrayList<RvCategoryData>
    // private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.topAppBar)
        // supportActionBar?.setDisplayHomeAsUpEnabled(true)

        dataCategory = ArrayList()
        binding.progressBar.isVisible = true

        mainViewModel =
            ViewModelProvider(this, MainViewModelFactory(MainRepository(retrofitService))).get(
                MainViewModel::class.java
            )

        try {
            getCategoryItem()
            binding.rvCategories.layoutManager = LinearLayoutManager(this);
            val adapter = CategoryAdapter(dataCategory, this)
            binding.rvCategories.adapter = adapter

            rvSearch = binding.rvSearch
            rvSearch.layoutManager = LinearLayoutManager(this)
            binding.rvSearch.visibility = View.VISIBLE
        } catch (e: Exception) {
            Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_SHORT).show()
        }


    }

    private fun getCategoryItem() {
        mainViewModel.categoryLiveData.observe(this) {
            val length = it.categories.size
            for (i in 1 until length) {
                dataCategory.add(RvCategoryData(it.categories[i].identifier))
            }
            binding.progressBar.isVisible = false
            binding.rvSearch.visibility = View.GONE
        }
    }

    private fun getSearchedItem(name: String, count: Int) {
        try {
            mainViewModel.getSearchedIcon(name, count)
            val data = ArrayList<RvSearchData>()
            mainViewModel.searchLiveData.observe(this) {
                binding.rvSearch.visibility = View.VISIBLE
                for (i in 0 until it.icons.size) {
                    var img = "";
                    if (it.icons[i].raster_sizes.isEmpty()) {
                        img = R.color.white.toString()
                    } else {
                        val s = it.icons[i].raster_sizes.size
                        img = it.icons[i].raster_sizes[s - 1].formats[0].preview_url
                    }
                    val name = it.icons[i].tags.joinToString { x -> x }
                    data.add(RvSearchData(img, name, "Tag :-", R.drawable.ic_download))
                }
                searchAdapter = SearchAdapter(data)
                binding.rvSearch.adapter = searchAdapter
                searchAdapter.notifyDataSetChanged()
            }
        } catch (e: Exception) {
            Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {

        menuInflater.inflate(R.menu.menu, menu)
        val searchManager: SearchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView: SearchView = menu.findItem(R.id.search).actionView.findViewById(R.id.search)
        searchView.setSearchableInfo(
            searchManager.getSearchableInfo(componentName)
        )
        searchView.isIconifiedByDefault = false

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                getSearchedItem(query, 30)
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                getSearchedItem(newText, 30)
                return false
            }
        })
        return true
    }

    override fun redirectToIconActivity(categoryName: String) {
        val intent = Intent(this@MainActivity, IconSetActivity::class.java)
        intent.putExtra("categoryName", categoryName)
        startActivity(intent)
    }

}