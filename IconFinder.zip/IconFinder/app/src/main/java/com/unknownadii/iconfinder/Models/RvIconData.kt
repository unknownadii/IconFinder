package com.unknownadii.iconfinder.Models

data class RvIconData(
    val icon: String,
    val download: Int,
    val iconId : String,
    val iconIdValue : Int,
)