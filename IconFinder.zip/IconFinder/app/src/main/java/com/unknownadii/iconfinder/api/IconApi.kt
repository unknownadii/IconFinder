package com.unknownadii.iconfinder.api

import com.unknownadii.iconfinder.Models.categoryModels.Category
import com.unknownadii.iconfinder.Models.iconModels.IconList
import com.unknownadii.iconfinder.Models.iconsetModels.IconSetList
import com.unknownadii.iconfinder.Models.iconsizeModels.IconSizeList
import com.unknownadii.iconfinder.Models.searchModels.SearchList
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

private const val BASE_URL = "https://api.iconfinder.com"

interface IconApi {

    @Headers(
        "Accept: application/json",
        "Authorization: Bearer X0vjEUN6KRlxbp2DoUkyHeM0VOmxY91rA6BbU5j3Xu6wDodwS0McmilLPBWDUcJ1"
    )
    @GET("/v4/categories")
    suspend fun getCategory(): Response<Category>


    @Headers(
        "Accept: application/json",
        "Authorization: Bearer X0vjEUN6KRlxbp2DoUkyHeM0VOmxY91rA6BbU5j3Xu6wDodwS0McmilLPBWDUcJ1"
    )
    @GET("/v4/icons/search")
    suspend fun getSearchedIcon(
        @Query("query") name: String,
        @Query("count") count: Int
    ): Response<SearchList>


    @Headers(
        "Accept: application/json",
        "Authorization: Bearer X0vjEUN6KRlxbp2DoUkyHeM0VOmxY91rA6BbU5j3Xu6wDodwS0McmilLPBWDUcJ1"
    )
    @GET("v4/categories/{categoryName}/iconsets")
    suspend fun getIconSet(
        @Path("categoryName") categoryName: String,
        @Query("count") count: Int
    ): Response<IconSetList>


    @Headers(
        "Accept: application/json",
        "Authorization: Bearer X0vjEUN6KRlxbp2DoUkyHeM0VOmxY91rA6BbU5j3Xu6wDodwS0McmilLPBWDUcJ1"
    )
    @GET("v4/iconsets/{id}/icons")
    suspend fun getIconSet(
        @Path("id") id: Int,
        @Query("count") count: Int
    ): Response<IconList>


    @Headers(
        "Accept: application/json",
        "Authorization: Bearer X0vjEUN6KRlxbp2DoUkyHeM0VOmxY91rA6BbU5j3Xu6wDodwS0McmilLPBWDUcJ1"
    )
    @GET("v4/icons/{iconId}")
    suspend fun getIconSize(
        @Path("iconId") id: Int
    ): Response<IconSizeList>

    companion object {
        var iconApi: IconApi? = null
        fun getInstance(): IconApi {
            if (iconApi == null) {
                val retrofit = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                iconApi = retrofit.create(IconApi::class.java)
            }
            return iconApi!!
        }
    }
}