package com.unknownadii.iconfinder.Models.iconsetModels

data class IconSetList(
    val iconsets: List<Iconset>,
    val total_count: Int
)