package com.unknownadii.iconfinder.recyclerview

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.toDrawable
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.unknownadii.iconfinder.Models.RvCategoryData
import com.unknownadii.iconfinder.Models.RvIconData
import com.unknownadii.iconfinder.R

class IconAdapter(private val mList: List<RvIconData>, private val move: moveIconSize) :
    RecyclerView.Adapter<IconAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.rv_icon, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val iconViewModel = mList[position]
        if (position % 5 == 0) {
            holder.llName.setBackgroundResource(R.color.light_pink)
        } else if (position % 2 == 0) {
            holder.llName.setBackgroundResource(R.color.light_blue)
        } else if (position % 2 != 0) {
            holder.llName.setBackgroundResource(R.color.light_green)
        }
        val icon = iconViewModel.icon
        val imgDownload = iconViewModel.download
        Glide.with(holder.icon.context)
            .load(icon)
            .into(holder.icon)
        Glide.with(holder.download.context)
            .load(imgDownload)
            .into(holder.download)
        holder.iconId.text = iconViewModel.iconId
        holder.iconIdValue.text = iconViewModel.iconIdValue.toString()
        holder.download.setOnClickListener {
            move.redirectToIconSize(iconViewModel.iconIdValue)
        }

    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val icon: ImageView = itemView.findViewById(R.id.iconIcon)
        val download: ImageView = itemView.findViewById(R.id.iconDownloadIcon)
        val llName: LinearLayout = itemView.findViewById(R.id.llRvIcon)
        val iconId: TextView = itemView.findViewById(R.id.tvRealIconName)
        val iconIdValue: TextView = itemView.findViewById(R.id.tvRealIconNameValue)
    }

    interface moveIconSize {
        fun redirectToIconSize(id: Int)
    }
}