package com.unknownadii.iconfinder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.GridView
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.unknownadii.iconfinder.Models.RvIconData
import com.unknownadii.iconfinder.Models.RvIconSetData
import com.unknownadii.iconfinder.api.IconApi
import com.unknownadii.iconfinder.databinding.ActivityIconBinding
import com.unknownadii.iconfinder.main.MainRepository
import com.unknownadii.iconfinder.main.MainViewModel
import com.unknownadii.iconfinder.main.MainViewModelFactory
import com.unknownadii.iconfinder.recyclerview.IconAdapter
import com.unknownadii.iconfinder.recyclerview.IconSetAdapter
import java.util.ArrayList
import kotlin.properties.Delegates

class IconActivity : AppCompatActivity(), IconAdapter.moveIconSize {
    lateinit var binding: ActivityIconBinding
    lateinit var mainViewModel: MainViewModel
    private val retrofitService = IconApi.getInstance()
    lateinit var dataIcon: ArrayList<RvIconData>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIconBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val intent = intent
        val str = intent.getStringExtra("id")!!.toInt()
        setSupportActionBar(binding.topAppBarIcon)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.topAppBarIcon.setNavigationOnClickListener {
            onBackPressed()
        }

        dataIcon = ArrayList()
        mainViewModel =
            ViewModelProvider(this, MainViewModelFactory(MainRepository(retrofitService))).get(
                MainViewModel::class.java
            )

        binding.progressBarIcon.isVisible = true
        if (str != null) {
            getIconItem(str, 30)
        }
        binding.rvIcon.layoutManager = GridLayoutManager(this, 2);
        val adapter = IconAdapter(dataIcon, this)
        binding.rvIcon.adapter = adapter
    }

    private fun getIconItem(id: Int, count: Int) {
        mainViewModel.getIcon(id, count)
        mainViewModel.iconLiveData.observe(this) {
            val length = it.icons.size
            for (i in 0 until length) {
                val totalLength = it.icons[i].raster_sizes.size
                val icon = it.icons[i].raster_sizes[totalLength - 1].formats[0].preview_url
                var download = R.drawable.ic_download
                val iconId = it.icons[i].icon_id
                if (it.icons[i].is_premium) {
                    download = R.drawable.ic_paid
                }
                dataIcon.add(RvIconData(icon, download, "Icon Id:- ", iconId))
            }
            binding.progressBarIcon.isVisible = false
        }
    }

    override fun redirectToIconSize(idIcon: Int) {
        val intent = Intent(this@IconActivity, IconSizeActivity::class.java)
        intent.putExtra("IconId", idIcon)
        startActivity(intent)
    }
}