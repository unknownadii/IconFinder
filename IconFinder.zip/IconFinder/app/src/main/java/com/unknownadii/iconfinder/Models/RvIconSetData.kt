package com.unknownadii.iconfinder.Models

data class RvIconSetData(
    val name: String,
    val nameValue: String,
    val id: String,
    val idValue: String,
    val img: Int
)