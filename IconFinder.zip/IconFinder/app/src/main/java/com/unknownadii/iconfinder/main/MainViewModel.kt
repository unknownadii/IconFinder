package com.unknownadii.iconfinder.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.unknownadii.iconfinder.Models.categoryModels.Category
import com.unknownadii.iconfinder.Models.iconModels.IconList
import com.unknownadii.iconfinder.Models.iconsetModels.IconSetList
import com.unknownadii.iconfinder.Models.iconsizeModels.IconSizeList
import com.unknownadii.iconfinder.Models.searchModels.SearchList
import kotlinx.coroutines.launch

class MainViewModel(private val repository: MainRepository) : ViewModel() {
    val categoryLiveData: LiveData<Category>
        get() = repository.category

    val searchLiveData: LiveData<SearchList>
        get() = repository.searchedData

    val iconSetLiveData: LiveData<IconSetList>
        get() = repository.iconSetData

    val iconLiveData: LiveData<IconList>
        get() = repository.iconData

    val iconSizeLiveData: LiveData<IconSizeList>
        get() = repository.iconSizeData

    fun getSearchedIcon(name: String, count: Int) {
        viewModelScope.launch {
            repository.getSearchedIcon(name, count)
        }
    }

    fun getIconSet(categoryName: String, count: Int) {
        viewModelScope.launch {
            repository.getIconSet(categoryName, count)
        }
    }

    fun getIcon(id: Int, count: Int) {
        viewModelScope.launch {
            repository.getIcon(id, count)
        }
    }

    fun getIconSize(id: Int) {
        viewModelScope.launch {
            repository.getIconSize(id)
        }
    }

    init {
        viewModelScope.launch {
            repository.getCategory()
        }
    }
}