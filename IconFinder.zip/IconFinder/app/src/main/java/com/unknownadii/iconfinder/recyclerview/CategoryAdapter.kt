package com.unknownadii.iconfinder.recyclerview

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.toDrawable
import androidx.recyclerview.widget.RecyclerView
import com.unknownadii.iconfinder.Models.RvCategoryData
import com.unknownadii.iconfinder.R

class CategoryAdapter(private val mList: List<RvCategoryData>, private val move: moveToIconSet) :
    RecyclerView.Adapter<CategoryAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.rv_category_layout, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val categoryViewModel = mList[position]
        if (position % 5 == 0) {
            holder.llName.setBackgroundResource(R.color.light_pink)
        } else if (position % 2 == 0) {
            holder.llName.setBackgroundResource(R.color.light_blue)
        } else if (position % 2 != 0) {
            holder.llName.setBackgroundResource(R.color.light_green)
        }
        holder.llName.setOnClickListener {
            move.redirectToIconActivity(categoryViewModel.name)
        }
        holder.textName.text = categoryViewModel.name

    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val textName: TextView = itemView.findViewById(R.id.tvNameCategory)
        val llName: LinearLayout = itemView.findViewById(R.id.llRvCategory)
    }

    interface moveToIconSet {
        fun redirectToIconActivity(categoryName:String)
    }
}