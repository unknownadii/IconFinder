package com.unknownadii.iconfinder.Models.iconsizeModels

data class IconSizeList(
    val icon_id: Int,
    val is_premium: Boolean,
    val raster_sizes: List<RasterSize>,
)