package com.unknownadii.iconfinder.di


import android.widget.ViewSwitcher
import com.unknownadii.iconfinder.api.IconApi
import com.unknownadii.iconfinder.main.MainRepository
import com.unknownadii.iconfinder.main.MainViewModel
import com.unknownadii.iconfinder.main.MainViewModelFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

private const val BASE_URL = "https://api.iconfinder.com"

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Singleton
    @Provides
    fun provideCategoryApi(): IconApi = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(IconApi::class.java)

    @Singleton
    @Provides
    fun provideMainRepository(api: IconApi): MainRepository = MainRepository(api)

}