package com.unknownadii.iconfinder.Models.searchModels

data class Format(
    val download_url: String,
    val format: String,
    val preview_url: String
)