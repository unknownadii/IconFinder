package com.unknownadii.iconfinder.Models.categoryModels

data class Category(
    val categories: List<CategoryX>,
    val total_count: Int
)