package com.unknownadii.iconfinder.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.unknownadii.iconfinder.Models.categoryModels.Category
import com.unknownadii.iconfinder.Models.iconModels.IconList
import com.unknownadii.iconfinder.Models.iconsetModels.IconSetList
import com.unknownadii.iconfinder.Models.iconsizeModels.IconSizeList
import com.unknownadii.iconfinder.Models.searchModels.SearchList
import com.unknownadii.iconfinder.api.IconApi
import javax.inject.Inject

class MainRepository(private val api: IconApi) {

    private val _category = MutableLiveData<Category>()
    val category: LiveData<Category>
        get() = _category

    private val _searchedData = MutableLiveData<SearchList>()
    val searchedData: LiveData<SearchList>
        get() = _searchedData

    private val _iconSetData = MutableLiveData<IconSetList>()
    val iconSetData: LiveData<IconSetList>
        get() = _iconSetData

    private val _iconData = MutableLiveData<IconList>()
    val iconData: LiveData<IconList>
        get() = _iconData

    private val _iconSizeData = MutableLiveData<IconSizeList>()
    val iconSizeData: LiveData<IconSizeList>
        get() = _iconSizeData

    suspend fun getCategory() {
        val result = api.getCategory()
        if (result.isSuccessful && result.body() != null) {
            _category.postValue(result.body())
        }
    }

    suspend fun getSearchedIcon(name: String, count: Int) {
        val result = api.getSearchedIcon(name, count)
        if (result.isSuccessful && result.body() != null) {
            _searchedData.postValue(result.body())
        }
    }

    suspend fun getIconSet(categoryName: String, count: Int) {
        val result = api.getIconSet(categoryName, count)
        if (result.isSuccessful && result.body() != null) {
            _iconSetData.postValue(result.body())
        }
    }

    suspend fun getIcon(id: Int, count: Int) {
        val result = api.getIconSet(id, count)
        if (result.isSuccessful && result.body() != null) {
            _iconData.postValue(result.body())
        }
    }

    suspend fun getIconSize(id: Int) {
        val result = api.getIconSize(id)
        if (result.isSuccessful && result.body() != null) {
            _iconSizeData.postValue(result.body())
        }
    }
}