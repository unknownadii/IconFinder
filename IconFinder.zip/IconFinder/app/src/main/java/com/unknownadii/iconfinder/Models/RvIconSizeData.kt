package com.unknownadii.iconfinder.Models

data class RvIconSizeData(
    val icon: String,
    val size: String,
    val sizeValue: String,
    val download: Int,
    val iconId : String,
    val iconIdValue : Int
)