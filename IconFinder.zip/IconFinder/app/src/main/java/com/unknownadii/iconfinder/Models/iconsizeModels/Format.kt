package com.unknownadii.iconfinder.Models.iconsizeModels

data class Format(
    val download_url: String,
    val format: String,
    val preview_url: String
)