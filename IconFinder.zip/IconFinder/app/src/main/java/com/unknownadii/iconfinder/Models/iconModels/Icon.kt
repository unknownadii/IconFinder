package com.unknownadii.iconfinder.Models.iconModels

data class Icon(
    val icon_id: Int,
    val is_premium: Boolean,
    val raster_sizes: List<RasterSize>
)