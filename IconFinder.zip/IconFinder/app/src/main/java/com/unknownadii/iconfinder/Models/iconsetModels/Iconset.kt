package com.unknownadii.iconfinder.Models.iconsetModels

data class Iconset(
    val iconset_id: Int,
    val name: String,
)