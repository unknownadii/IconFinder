package com.unknownadii.iconfinder.Models

data class RvCategoryData(
    val name: String
)