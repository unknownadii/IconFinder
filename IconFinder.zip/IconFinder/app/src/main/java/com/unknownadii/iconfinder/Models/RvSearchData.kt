package com.unknownadii.iconfinder.Models

data class RvSearchData(
    val img: String,
    val name: String,
    val tag: String,
    val download : Int
)