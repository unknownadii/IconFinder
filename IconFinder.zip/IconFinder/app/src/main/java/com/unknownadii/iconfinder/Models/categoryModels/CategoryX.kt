package com.unknownadii.iconfinder.Models.categoryModels

data class CategoryX(
    val identifier: String,
    val name: String
)