package com.unknownadii.iconfinder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.unknownadii.iconfinder.Models.RvIconData
import com.unknownadii.iconfinder.Models.RvIconSizeData
import com.unknownadii.iconfinder.api.IconApi
import com.unknownadii.iconfinder.databinding.ActivityIconBinding
import com.unknownadii.iconfinder.databinding.ActivityIconSizeBinding
import com.unknownadii.iconfinder.main.MainRepository
import com.unknownadii.iconfinder.main.MainViewModel
import com.unknownadii.iconfinder.main.MainViewModelFactory
import com.unknownadii.iconfinder.recyclerview.IconAdapter
import com.unknownadii.iconfinder.recyclerview.IconSizeAdapter
import java.util.ArrayList

class IconSizeActivity : AppCompatActivity() {
    lateinit var binding: ActivityIconSizeBinding
    lateinit var mainViewModel: MainViewModel
    private val retrofitService = IconApi.getInstance()
    lateinit var dataIconSize: ArrayList<RvIconSizeData>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIconSizeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val intent1 = intent
        val id = intent1.getIntExtra("IconId", 0)

        setSupportActionBar(binding.topAppBarIconSize)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.topAppBarIconSize.setNavigationOnClickListener {
            onBackPressed()
        }

        dataIconSize = ArrayList()
        mainViewModel =
            ViewModelProvider(this, MainViewModelFactory(MainRepository(retrofitService))).get(
                MainViewModel::class.java
            )

        binding.progressBarIconSize.isVisible = true
        if (id != null) {
            dataIconSizeItem(id)
        }
        binding.rvIconSize.layoutManager = GridLayoutManager(this, 2);
        val adapter = IconSizeAdapter(dataIconSize)
        binding.rvIconSize.adapter = adapter
    }

    private fun dataIconSizeItem(id: Int) {
        mainViewModel.getIconSize(id)
        mainViewModel.iconSizeLiveData.observe(this) {
            val length = it.raster_sizes.size
            for (i in 0 until length) {
                val icon = it.raster_sizes[i].formats[0].preview_url
                var download = R.drawable.ic_download
                if (it.is_premium) {
                    download = R.drawable.ic_paid
                }
                val size = it.raster_sizes[i].size
                val iconIdValue = it.icon_id
                dataIconSize.add(
                    RvIconSizeData(
                        icon, "Icon:- ", "$size*$size", download, "Icon Id:- ", iconIdValue
                    )
                )
            }
            binding.progressBarIconSize.isVisible = false
        }
    }
}