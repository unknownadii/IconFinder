package com.unknownadii.iconfinder.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.unknownadii.iconfinder.Models.RvCategoryData
import com.unknownadii.iconfinder.Models.RvSearchData
import com.unknownadii.iconfinder.R

class SearchAdapter(private val mList: List<RvSearchData>) :
    RecyclerView.Adapter<SearchAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.rv_search_layout, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val categoryViewModel = mList[position]
        if (position % 5 == 0) {
            holder.llName.setBackgroundResource(R.color.light_pink)
            holder.llName2.setBackgroundResource(R.color.light_pink)
        } else if (position % 2 == 0) {
            holder.llName.setBackgroundResource(R.color.light_blue)
            holder.llName2.setBackgroundResource(R.color.light_blue)
        } else if (position % 2 != 0) {
            holder.llName.setBackgroundResource(R.color.light_green)
            holder.llName2.setBackgroundResource(R.color.light_green)
        }
        holder.textName.text = categoryViewModel.name
        holder.tag.text = categoryViewModel.tag
        // sets the image to the imageview from our itemHolder class
        val imageUrl = categoryViewModel.img
        val imgDownload = categoryViewModel.download
        Glide.with(holder.icon.context)
            .load(imageUrl)
            .into(holder.icon)
        Glide.with(holder.download.context)
            .load(imgDownload)
            .into(holder.download)

    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val textName: TextView = itemView.findViewById(R.id.tagsSearch)
        val tag: TextView = itemView.findViewById(R.id.tvNameSearch)
        val icon: ImageView = itemView.findViewById(R.id.iconSearch)
        val download: ImageView = itemView.findViewById(R.id.downloadSearch)
        val llName: LinearLayout = itemView.findViewById(R.id.llRvSearch)
        val llName2: LinearLayout = itemView.findViewById(R.id.llRvSearch)
    }
}